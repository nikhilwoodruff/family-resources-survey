# family_resources_survey

This is a lightweight Python package to store, manage and load Family Resources Survey microdata.